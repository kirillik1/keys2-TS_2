<?php
session_start();
require_once 'config.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['admin', 'manager'])) {
    echo json_encode(['success' => false, 'message' => 'Доступ запрещён']);
    exit;
}

$name = $_POST['name'] ?? '';
$latitude = $_POST['latitude'] ?? '';
$longitude = $_POST['longitude'] ?? '';

if ($name && $latitude && $longitude) {
    try {
        $conn = get_db_connection();
        $stmt = $conn->prepare("INSERT INTO projects (project_name, latitude, longitude, manager_id) VALUES (?, ?, ?, ?)");
        $stmt->execute([$name, $latitude, $longitude, $_SESSION['user_id']]);
        echo json_encode(['success' => true, 'message' => 'Объект успешно добавлен']);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Ошибка базы данных: ' . $e->getMessage()]);
    } finally {
        $conn = null;
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Заполните все поля']);
}
?>