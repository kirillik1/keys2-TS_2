<?php
session_start();
require_once 'config.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    echo json_encode(['success' => false, 'message' => 'Доступ запрещён']);
    exit;
}

$name = $_POST['name'] ?? '';
$telegram_id = $_POST['telegram_id'] ?? '';
$role = $_POST['role'] ?? '';

if ($name && $telegram_id && $role) {
    $conn = get_db_connection();
    $stmt = $conn->prepare("INSERT INTO users (user_id, name, role, points) VALUES (?, ?, ?, 0)");
    $stmt->execute([$telegram_id, $name, $role]);
    echo json_encode(['success' => true]);
    $conn = null;
} else {
    echo json_encode(['success' => false, 'message' => 'Заполните все поля']);
}