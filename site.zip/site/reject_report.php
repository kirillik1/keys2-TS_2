<?php
session_start();
require_once 'config.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['admin', 'manager'])) {
    echo json_encode(['success' => false, 'message' => 'Доступ запрещён']);
    exit;
}

$report_id = $_POST['report_id'] ?? '';

if ($report_id) {
    $conn = get_db_connection();
    $stmt = $conn->prepare("
        DELETE FROM reports
        WHERE report_id = ? AND EXISTS (
            SELECT 1 FROM projects p
            WHERE p.project_id = reports.project_id
            AND (p.manager_id = ? OR ? = 'admin')
        )
    ");
    $stmt->execute([$report_id, $_SESSION['user_id'], $_SESSION['role']]);
    $affected = $stmt->rowCount();
    $conn = null;

    if ($affected > 0) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Отчёт не найден или доступ запрещён']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Укажите ID отчёта']);
}
?>