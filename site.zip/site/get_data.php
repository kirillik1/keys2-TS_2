<?php
session_start();
require_once 'config.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['error' => 'Не авторизован']);
    exit;
}

$conn = get_db_connection();
$type = $_GET['type'] ?? '';

if ($type === 'employees' && $_SESSION['role'] === 'admin') {
    $stmt = $conn->query("SELECT user_id, name, role, points FROM users");
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
} elseif ($type === 'objects') {
    if ($_SESSION['role'] === 'admin') {
        $stmt = $conn->query("SELECT project_id, project_name, latitude, longitude FROM projects");
    } else {
        $stmt = $conn->prepare("SELECT project_id, project_name, latitude, longitude FROM projects WHERE manager_id = ?");
        $stmt->execute([$_SESSION['user_id']]);
    }
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
} elseif ($type === 'reports') {
    $stmt = $conn->prepare("
        SELECT r.report_id, r.user_id, u.name AS user_name, r.project_id, p.project_name, r.report_date, 
               r.tasks_completed, r.issues, r.approved
        FROM reports r
        JOIN users u ON r.user_id = u.user_id
        JOIN projects p ON r.project_id = p.project_id
        WHERE p.manager_id = ? OR ? = 'admin'
    ");
    $stmt->execute([$_SESSION['user_id'], $_SESSION['role']]);
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
} elseif ($type === 'pending_reports') {
    $stmt = $conn->prepare("
        SELECT r.report_id, r.user_id, u.name AS user_name, r.project_id, p.project_name, r.report_date, 
               r.tasks_completed, r.issues
        FROM reports r
        JOIN users u ON r.user_id = u.user_id
        JOIN projects p ON r.project_id = p.project_id
        WHERE r.approved = 0 AND (p.manager_id = ? OR ? = 'admin')
    ");
    $stmt->execute([$_SESSION['user_id'], $_SESSION['role']]);
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
} else {
    echo json_encode([]);
}

$conn = null;
?>