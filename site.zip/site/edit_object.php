<?php
session_start();
require_once 'config.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['admin', 'manager'])) {
    echo json_encode(['success' => false, 'message' => 'Доступ запрещён']);
    exit;
}

$project_id = $_POST['project_id'] ?? '';
$name = $_POST['name'] ?? '';

if ($project_id && $name) {
    $conn = get_db_connection();
    $stmt = $conn->prepare("UPDATE projects SET project_name = ? WHERE project_id = ? AND (manager_id = ? OR ? = 'admin')");
    $stmt->execute([$name, $project_id, $_SESSION['user_id'], $_SESSION['role']]);
    echo json_encode(['success' => true]);
    $conn = null;
} else {
    echo json_encode(['success' => false, 'message' => 'Ошибка данных']);
}