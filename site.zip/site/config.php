<?php
function get_db_connection() {
    $db_config = [
        'host' => 'localhost',
        'user' => 'root',
        'password' => '888999000',
        'db' => 'report_db',
        'port' => 3306
    ];
    try {
        $conn = new PDO(
            "mysql:host={$db_config['host']};dbname={$db_config['db']};port={$db_config['port']}",
            $db_config['user'],
            $db_config['password']
        );
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $conn;
    } catch (PDOException $e) {
        die("Ошибка подключения: " . $e->getMessage());
    }
}