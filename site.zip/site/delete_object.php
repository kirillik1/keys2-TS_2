<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config.php';

if (!isset($_SESSION['user_id'])) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Не авторизован']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['project_id'])) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Неверный запрос']);
    exit;
}

$project_id = $_POST['project_id'];

$conn = get_db_connection();

try {
    $conn->beginTransaction();

    // Удаляем связанные записи из shifts
    $stmt = $conn->prepare("DELETE FROM shifts WHERE object_id = ?");
    $stmt->execute([$project_id]);

    // Удаляем связанные отчёты из reports
    $stmt = $conn->prepare("DELETE FROM reports WHERE project_id = ?");
    $stmt->execute([$project_id]);

    // Удаляем сам объект из projects
    $stmt = $conn->prepare("DELETE FROM projects WHERE project_id = ?");
    $stmt->execute([$project_id]);

    $conn->commit();

    header('Content-Type: application/json');
    echo json_encode(['success' => true]);
} catch (Exception $e) {
    $conn->rollBack();
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Ошибка при удалении: ' . $e->getMessage()]);
}

$conn = null;
?>