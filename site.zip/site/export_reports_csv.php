<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['user_id'])) {
    die('Не авторизован');
}

ob_clean();
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment;filename="reports_' . date('Y-m-d_H-i-s') . '.csv"');
header('Cache-Control: max-age=0');

$output = fopen('php://output', 'w');
fwrite($output, "\xEF\xBB\xBF"); // BOM для UTF-8

fputcsv($output, ['ID', 'Сотрудник', 'Объект', 'Дата', 'Время начала', 'Время окончания', 'Задачи', 'Проблемы', 'Статус'], ';');

$conn = get_db_connection();
if ($_SESSION['role'] === 'admin') {
    $stmt = $conn->query("
        SELECT r.report_id, r.user_id, u.name AS user_name, r.project_id, p.project_name, 
               r.report_date, r.tasks_completed, r.issues, r.approved, r.start_time, r.end_time
        FROM reports r
        JOIN users u ON r.user_id = u.user_id
        JOIN projects p ON r.project_id = p.project_id
    ");
} else {
    $stmt = $conn->prepare("
        SELECT r.report_id, r.user_id, u.name AS user_name, r.project_id, p.project_name, 
               r.report_date, r.tasks_completed, r.issues, r.approved, r.start_time, r.end_time
        FROM reports r
        JOIN users u ON r.user_id = u.user_id
        JOIN projects p ON r.project_id = p.project_id
        WHERE p.manager_id = ?
    ");
    $stmt->execute([$_SESSION['user_id']]);
}

$reports = $stmt->fetchAll(PDO::FETCH_ASSOC);
$conn = null;

if (empty($reports)) {
    fputcsv($output, ['Нет отчётов для скачивания'], ';');
} else {
    foreach ($reports as $report) {
        fputcsv($output, [
            $report['report_id'],
            $report['user_name'] . ' (' . $report['user_id'] . ')',
            $report['project_name'] . ' (' . $report['project_id'] . ')',
            $report['report_date'],
            $report['start_time'],
            $report['end_time'],
            $report['tasks_completed'],
            $report['issues'],
            $report['approved'] ? 'Одобрен' : 'На проверке'
        ], ';');
    }
}

fclose($output);
exit;
?>