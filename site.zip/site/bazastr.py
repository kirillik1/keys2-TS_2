from flask import Flask, render_template, redirect, request, session
from flask_mysqldb import MySQL
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# Настройки MySQL
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'your_user'
app.config['MYSQL_PASSWORD'] = 'your_password'
app.config['MYSQL_DB'] = 'reportwork_db'

mysql = MySQL(app)

@app.route('/')
def index():
    if 'loggedin' in session:
        return redirect('/dashboard')
    return render_template('login.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        cur = mysql.connection.cursor()
        cur.execute("SELECT id, password, role FROM users WHERE username = %s", (username,))
        user = cur.fetchone()
        cur.close()
        if user and check_password_hash(user[1], password):
            session['loggedin'] = True
            session['id'] = user[0]
            session['role'] = user[2]
            return redirect('/dashboard')
    return render_template('login.html', error="Неверные данные")

@app.route('/dashboard')
def dashboard():
    if 'loggedin' not in session:
        return redirect('/login')
    return render_template('dashboard.html', role=session['role'])

@app.route('/logout')
def logout():
    session.pop('loggedin', None)
    session.pop('id', None)
    session.pop('role', None)
    return redirect('/login')

if __name__ == '__main__':
    app.run(debug=True)
