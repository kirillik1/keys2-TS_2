<?php
session_start();
require_once 'config.php'; // Файл с функцией get_db_connection

header('Content-Type: application/json');

$username = $_POST['username'] ?? '';
$password = $_POST['password'] ?? '';

$conn = get_db_connection();
$stmt = $conn->prepare("SELECT user_id, name, role FROM users WHERE name = ? AND role IN ('admin', 'manager')");
$stmt->execute([$username]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if ($user && $password === 'password123') { // Простая проверка пароля (замените на хеширование)
    $_SESSION['user_id'] = $user['user_id'];
    $_SESSION['name'] = $user['name'];
    $_SESSION['role'] = $user['role'];
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false]);
}

$conn = null;