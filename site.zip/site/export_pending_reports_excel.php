<?php
session_start();
require_once 'config.php';

// Проверка авторизации
if (!isset($_SESSION['user_id'])) {
    die('Не авторизован');
}

// Очистка буфера вывода
ob_clean();

// Установка заголовков для CSV
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment;filename="pending_reports_' . date('Y-m-d_H-i-s') . '.csv"');
header('Cache-Control: max-age=0');

// Открываем поток для вывода
$output = fopen('php://output', 'w');

// Добавляем BOM для UTF-8
fwrite($output, "\xEF\xBB\xBF");

// Заголовки таблицы
fputcsv($output, [
    'ID',
    'Сотрудник',
    'Объект',
    'Дата',
    'Время начала',
    'Время окончания',
    'Задачи',
    'Проблемы'
], ';');

// Подключение к базе данных
$conn = get_db_connection();

if ($_SESSION['role'] === 'admin') {
    $stmt = $conn->query("
        SELECT r.report_id, r.user_id, u.name AS user_name, r.project_id, p.project_name, 
               r.report_date, r.tasks_completed, r.issues, r.start_time, r.end_time
        FROM reports r
        JOIN users u ON r.user_id = u.user_id
        JOIN projects p ON r.project_id = p.project_id
        WHERE r.approved = 0
    ");
} else {
    $stmt = $conn->prepare("
        SELECT r.report_id, r.user_id, u.name AS user_name, r.project_id, p.project_name, 
               r.report_date, r.tasks_completed, r.issues, r.start_time, r.end_time
        FROM reports r
        JOIN users u ON r.user_id = u.user_id
        JOIN projects p ON r.project_id = p.project_id
        WHERE r.approved = 0 AND p.manager_id = ?
    ");
    $stmt->execute([$_SESSION['user_id']]);
}

$reports = $stmt->fetchAll(PDO::FETCH_ASSOC);
$conn = null;

if (empty($reports)) {
    fputcsv($output, ['Нет отчётов на рассмотрении'], ';');
} else {
    foreach ($reports as $report) {
        fputcsv($output, [
            $report['report_id'],
            $report['user_name'] . ' (' . $report['user_id'] . ')',
            $report['project_name'] . ' (' . $report['project_id'] . ')',
            $report['report_date'],
            $report['start_time'],
            $report['end_time'],
            $report['tasks_completed'],
            $report['issues']
        ], ';');
    }
}

fclose($output);
exit;
?>