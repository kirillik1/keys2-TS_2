<?php
// Параметры подключения к базе данных
$db_config = [
    'host' => 'localhost',
    'user' => 'root',
    'password' => '888999000',
    'db' => 'report_db',
    'port' => 3306
];

// Подключение к базе данных
function get_db_connection() {
    global $db_config;
    try {
        $conn = new PDO(
            "mysql:host={$db_config['host']};dbname={$db_config['db']};port={$db_config['port']}",
            $db_config['user'],
            $db_config['password']
        );
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $conn;
    } catch (PDOException $e) {
        die("Ошибка подключения: " . $e->getMessage());
    }
}

// Проверка авторизации (через сессии)
session_start();
$is_logged_in = isset($_SESSION['user_id']);
$user_role = $is_logged_in ? $_SESSION['role'] : null;
$user_name = $is_logged_in ? $_SESSION['name'] : '';
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>REPORTWORK</title>
    <style>
        body {
            font-family: 'Inter', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #000;
            color: #fff;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        .navbar {
            width: 100%;
            background-color: rgba(0, 0, 0, 0.8);
            display: flex;
            justify-content: center;
            padding: 10px 0;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1000;
        }
        .navbar a {
            color: #fff;
            text-decoration: none;
            font-size: 16px;
            margin: 0 10px;
            padding: 8px 16px;
            border-radius: 5px;
            transition: background 0.3s;
        }
        .navbar a:hover {
            background-color: #7f57ff;
        }
        .admin-login {
            position: absolute;
            right: 20px;
        }
        .container {
            max-width: 900px;
            padding: 100px 20px 40px;
            text-align: center;
            display: <?php echo $is_logged_in ? 'none' : 'block'; ?>;
        }
        .logo img {
            width: 300px;
            height: auto;
        }
        h1 {
            font-size: 36px;
            font-weight: 700;
            margin-bottom: 20px;
        }
        .section {
            background: rgba(255, 255, 255, 0.1);
            padding: 15px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(127, 87, 255, 0.5);
            margin-bottom: 30px;
        }
        .section h2 {
            font-size: 24px;
            font-weight: 600;
            margin-bottom: 10px;
            color: #7f57ff;
        }
        .list {
            list-style: none;
            padding: 0;
        }
        .list li {
            font-size: 18px;
            margin: 8px 0;
            padding-left: 20px;
            position: relative;
        }
        .list li::before {
            content: '•';
            color: #7f57ff;
            position: absolute;
            left: 0;
        }
        .qr-code {
            text-align: center;
            margin-top: 20px;
        }
        .button {
            background-color: #7f57ff;
            color: #fff;
            border: none;
            padding: 8px 16px;
            font-size: 14px;
            cursor: pointer;
            border-radius: 5px;
            text-decoration: none;
            margin: 5px;
            transition: background 0.3s;
            display: inline-block;
        }
        .button:hover {
            background-color: #6541cc;
        }
        .button.delete {
            background-color: #ff4444;
        }
        .button.delete:hover {
            background-color: #cc3333;
        }
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            z-index: 2000;
            justify-content: center;
            align-items: center;
        }
        .modal-content {
            background: #fff;
            color: #000;
            padding: 20px;
            border-radius: 10px;
            width: 350px;
            text-align: center;
        }
        .modal-content input, .modal-content select {
            width: 100%;
            padding: 6px;
            margin: 8px 0;
            border: 1px solid #7f57ff;
            border-radius: 5px;
            box-sizing: border-box;
        }
        .admin-panel {
            display: <?php echo $is_logged_in ? 'block' : 'none'; ?>;
            max-width: 900px;
            padding: 80px 20px 20px;
            text-align: center;
        }
        .admin-tabs {
            display: flex;
            justify-content: center;
            margin-bottom: 20px;
        }
        .tab-button {
            background: rgba(255, 255, 255, 0.1);
            color: #fff;
            padding: 8px 20px;
            border-radius: 5px 5px 0 0;
            cursor: pointer;
            margin: 0 5px;
            transition: background 0.3s;
        }
        .tab-button.active {
            background: #7f57ff;
        }
        .admin-section {
            display: none;
            background: rgba(255, 255, 255, 0.1);
            padding: 15px;
            border-radius: 0 0 10px 10px;
            box-shadow: 0 0 10px rgba(127, 87, 255, 0.5);
        }
        .admin-section.active {
            display: block;
        }
        .table-container {
            max-height: 300px;
            overflow-y: auto;
            margin-top: 10px;
        }
        .table {
            width: 100%;
            border-collapse: collapse;
        }
        .table th, .table td {
            padding: 8px;
            border: 1px solid #7f57ff;
            font-size: 14px;
        }
        .table th {
            background: #7f57ff;
            color: #fff;
            position: sticky;
            top: 0;
        }
        .table td {
            color: #fff;
        }
    </style>
</head>
<body>
    <div class="navbar" id="navbar">
        <a href="#history" id="historyLink" style="display: <?php echo $is_logged_in ? 'none' : 'inline'; ?>;">История</a>
        <a href="#target" id="targetLink" style="display: <?php echo $is_logged_in ? 'none' : 'inline'; ?>;">Кому подходит</a>
        <a href="#bot" id="botLink" style="display: <?php echo $is_logged_in ? 'none' : 'inline'; ?>;">Перейти к боту</a>
        <div class="admin-login" id="loginButton" style="display: <?php echo $is_logged_in ? 'none' : 'block'; ?>;">
            <a href="#" class="button" onclick="showLoginModal()">Вход</a>
        </div>
    </div>

    <!-- Модальное окно авторизации -->
    <div class="modal" id="loginModal">
        <div class="modal-content">
            <h2>Вход</h2>
            <input type="text" id="username" placeholder="Логин">
            <input type="password" id="password" placeholder="Пароль">
            <button class="button" onclick="login()">Войти</button>
            <button class="button" onclick="closeLoginModal()" style="background: #666">Отмена</button>
        </div>
    </div>

    <!-- Модальное окно добавления сотрудника -->
    <div class="modal" id="addEmployeeModal">
        <div class="modal-content">
            <h2>Добавить сотрудника</h2>
            <input type="text" id="employeeName" placeholder="ФИО">
            <input type="text" id="employeeTelegramId" placeholder="Telegram ID">
            <select id="employeeRole">
                <option value="employee">Сотрудник</option>
                <option value="manager">Руководитель</option>
                <option value="admin">Администратор</option>
            </select>
            <button class="button" onclick="addEmployee()">Добавить</button>
            <button class="button" onclick="closeModal('addEmployeeModal')" style="background: #666">Отмена</button>
        </div>
    </div>

    <!-- Модальное окно добавления объекта -->
    <div class="modal" id="addObjectModal">
        <div class="modal-content">
            <h2>Добавить объект</h2>
            <input type="text" id="objectName" placeholder="Название объекта">
            <input type="number" step="any" id="objectLatitude" placeholder="Широта">
            <input type="number" step="any" id="objectLongitude" placeholder="Долгота">
            <button class="button" onclick="addObject()">Добавить</button>
            <button class="button" onclick="closeModal('addObjectModal')" style="background: #666">Отмена</button>
        </div>
    </div>

    <!-- Основной контент -->
    <div class="container" id="mainContent">
        <div class="logo">
            <img src="логодля.jpg" alt="Логотип">
        </div>
        <h1>Автоматизация отчетности с Telegram-ботом</h1>
        
        <div class="section" id="history">
            <h2>История появления системы</h2>
            <p>Система REPORTWORK была разработана для автоматизации отчетности выездных сотрудников. 
            Она помогает сократить время на заполнение отчетов, улучшить обработку данных и упростить контроль за выполнением задач.</p>
        </div>
        
        <div class="section" id="target">
            <h2>Для кого предназначена система</h2>
            <p>REPORTWORK подходит для компаний с выездными сотрудниками:</p>
            <ul class="list">
                <li>Курьерских и логистических служб.</li>
                <li>Сервисных и ремонтных компаний.</li>
                <li>Клининг- и обслуживающих организаций.</li>
                <li>Аудиторских и инспекционных служб.</li>
            </ul>
        </div>
        
        <div class="qr-code" id="bot">
            <h2>Перейдите к боту</h2>
            <img src="QR2.jpg" alt="QR код для Telegram-бота" width="450px">
            <br>
            <a href="https://t.me/reportwork_bot" class="button" target="_blank">Открыть Telegram-бот</a>
        </div>
    </div>

    <!-- Админ-панель -->
    <div class="admin-panel" id="adminPanel">
        <h1>Панель администратора</h1>
        <p>Добро пожаловать, <span id="adminName"><?php echo htmlspecialchars($user_name); ?></span>!</p>
        
        <div class="admin-tabs">
            <div class="tab-button active" onclick="openTab('adminControls')" id="tabEmployees" style="display: <?php echo $user_role === 'admin' ? 'block' : 'none'; ?>;">Сотрудники</div>
            <div class="tab-button <?php echo $user_role !== 'admin' ? 'active' : ''; ?>" onclick="openTab('objectControls')" id="tabObjects">Объекты</div>
            <div class="tab-button" onclick="openTab('reportControls')" id="tabReports">Отчеты</div>
            <div class="tab-button" onclick="openTab('pendingReports')" id="tabPendingReports">Отчёты на рассмотрении</div>
        </div>

        <div class="admin-section <?php echo $user_role === 'admin' ? 'active' : ''; ?>" id="adminControls">
            <h2>Управление сотрудниками</h2>
            <button class="button" onclick="showModal('addEmployeeModal')">Добавить сотрудника</button>
            <div class="table-container">
                <table class="table" id="employeeTable">
                    <thead>
                        <tr>
                            <th>Telegram ID</th>
                            <th>ФИО</th>
                            <th>Роль</th>
                            <th>Баллы</th>
                        </tr>
                    </thead>
                    <tbody id="employeeList"></tbody>
                </table>
            </div>
        </div>

        <div class="admin-section <?php echo $user_role !== 'admin' ? 'active' : ''; ?>" id="objectControls">
            <h2>Управление объектами</h2>
            <button class="button" onclick="showModal('addObjectModal')">Добавить объект</button>
            <div class="table-container">
                <table class="table" id="objectTable">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Название объекта</th>
                            <th>Широта</th>
                            <th>Долгота</th>
                            <th>Действия</th>
                        </tr>
                    </thead>
                    <tbody id="objectList"></tbody>
                </table>
            </div>
        </div>

        <div class="admin-section" id="reportControls">
            <h2>Отчеты</h2>
            <div style="display: flex; justify-content: center; gap: 10px;">
                <button class="button" onclick="downloadApprovedReportsExcel()">Скачать все отчёты в Excel</button>
            </div>
            <div class="table-container">
                <table class="table" id="reportTable">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Сотрудник</th>
                            <th>Объект</th>
                            <th>Дата</th>
                            <th>Задачи</th>
                            <th>Проблемы</th>
                            <th>Статус</th>
                        </tr>
                    </thead>
                    <tbody id="reportList"></tbody>
                </table>
            </div>
        </div>

        <div class="admin-section" id="pendingReports">
            <h2>Отчёты на рассмотрении</h2>
            <button class="button" onclick="downloadPendingReportsExcel()">Скачать в Excel</button>
            <div class="table-container">
                <table class="table" id="pendingReportTable">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Сотрудник</th>
                            <th>Объект</th>
                            <th>Дата</th>
                            <th>Задачи</th>
                            <th>Проблемы</th>
                            <th>Действия</th>
                        </tr>
                    </thead>
                    <tbody id="pendingReportList"></tbody>
                </table>
            </div>
        </div>

        <button class="button" onclick="logout()" style="background: #ff4444">Выйти</button>
    </div>

    <script>
        // Показать модальное окно логина
        function showLoginModal() {
            document.getElementById('loginModal').style.display = 'flex';
        }

        // Закрыть модальное окно логина
        function closeLoginModal() {
            document.getElementById('loginModal').style.display = 'none';
        }

        // Показать модальное окно
        function showModal(modalId) {
            document.getElementById(modalId).style.display = 'flex';
        }

        // Закрыть модальное окно
        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }

        // Функция авторизации
        function login() {
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;

            fetch('login.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `username=${encodeURIComponent(username)}&password=${encodeURIComponent(password)}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    window.location.reload();
                } else {
                    alert('Неверный логин или пароль');
                }
            })
            .catch(error => console.error('Ошибка:', error));
        }

        // Функция выхода
        function logout() {
            fetch('logout.php')
            .then(() => window.location.reload())
            .catch(error => console.error('Ошибка:', error));
        }

        // Переключение вкладок
        function openTab(tabId) {
            document.querySelectorAll('.admin-section').forEach(section => {
                section.classList.remove('active');
            });
            document.querySelectorAll('.tab-button').forEach(button => {
                button.classList.remove('active');
            });

            const selectedSection = document.getElementById(tabId);
            if (selectedSection) {
                selectedSection.classList.add('active');
                document.querySelector(`[onclick="openTab('${tabId}')"]`).classList.add('active');
            }

            if (tabId === 'adminControls') loadEmployees();
            else if (tabId === 'objectControls') loadObjects();
            else if (tabId === 'reportControls') loadReports();
            else if (tabId === 'pendingReports') loadPendingReports();
        }

        // Загрузка сотрудников
        function loadEmployees() {
            fetch('get_data.php?type=employees')
            .then(response => response.json())
            .then(data => {
                const employeeList = document.getElementById('employeeList');
                employeeList.innerHTML = '';
                data.forEach(employee => {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${employee.user_id}</td>
                        <td>${employee.name}</td>
                        <td>${employee.role}</td>
                        <td>${employee.points}</td>
                    `;
                    employeeList.appendChild(row);
                });
            });
        }

        // Загрузка объектов
        function loadObjects() {
            console.log('Загрузка объектов...');
            fetch('get_data.php?type=objects')
            .then(response => response.json())
            .then(data => {
                console.log('Полученные объекты:', data);
                const objectList = document.getElementById('objectList');
                objectList.innerHTML = '';
                if (data.length === 0) {
                    objectList.innerHTML = '<tr><td colspan="5">Нет объектов</td></tr>';
                } else {
                    data.forEach(obj => {
                        const row = document.createElement('tr');
                        row.innerHTML = `
                            <td>${obj.project_id}</td>
                            <td>${obj.project_name}</td>
                            <td>${obj.latitude}</td>
                            <td>${obj.longitude}</td>
                            <td>
                                <button class="button" onclick="editObject(${obj.project_id})">Редактировать</button>
                                <button class="button delete" onclick="deleteObject(${obj.project_id})">Удалить</button>
                            </td>
                        `;
                        objectList.appendChild(row);
                    });
                }
            })
            .catch(error => console.error('Ошибка при загрузке объектов:', error));
        }

        // Загрузка отчётов
        function loadReports() {
            fetch('get_data.php?type=reports')
            .then(response => response.json())
            .then(data => {
                const reportList = document.getElementById('reportList');
                reportList.innerHTML = '';
                data.forEach(report => {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${report.report_id}</td>
                        <td>${report.user_name} (${report.user_id})</td>
                        <td>${report.project_name} (${report.project_id})</td>
                        <td>${report.report_date}</td>
                        <td>${report.tasks_completed}</td>
                        <td>${report.issues}</td>
                        <td>${report.approved ? 'Одобрен' : 'На проверке'}</td>
                    `;
                    reportList.appendChild(row);
                });
            });
        }

        // Загрузка отчётов на рассмотрении
        function loadPendingReports() {
            console.log('Загрузка отчётов на рассмотрении...');
            fetch('get_data.php?type=pending_reports')
            .then(response => response.json())
            .then(data => {
                console.log('Полученные данные:', data);
                const pendingReportList = document.getElementById('pendingReportList');
                pendingReportList.innerHTML = '';
                if (data.length === 0) {
                    pendingReportList.innerHTML = '<tr><td colspan="7">Нет отчётов на рассмотрении</td></tr>';
                } else {
                    data.forEach(report => {
                        const row = document.createElement('tr');
                        row.innerHTML = `
                            <td>${report.report_id}</td>
                            <td>${report.user_name} (${report.user_id})</td>
                            <td>${report.project_name} (${report.project_id})</td>
                            <td>${report.report_date}</td>
                            <td>${report.tasks_completed}</td>
                            <td>${report.issues}</td>
                            <td>
                                <button class="button" onclick="approveReport(${report.report_id})">Одобрить</button>
                                <button class="button" onclick="rejectReport(${report.report_id})" style="background: #ff4444">Отклонить</button>
                            </td>
                        `;
                        pendingReportList.appendChild(row);
                    });
                }
            })
            .catch(error => console.error('Ошибка:', error));
        }

        // Добавление сотрудника
        function addEmployee() {
            const name = document.getElementById('employeeName').value;
            const telegramId = document.getElementById('employeeTelegramId').value;
            const role = document.getElementById('employeeRole').value;

            if (name && telegramId && role) {
                fetch('add_employee.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: `name=${encodeURIComponent(name)}&telegram_id=${encodeURIComponent(telegramId)}&role=${encodeURIComponent(role)}`
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        closeModal('addEmployeeModal');
                        loadEmployees();
                    } else {
                        alert(data.message);
                    }
                });
            } else {
                alert('Заполните все поля');
            }
        }

        // Добавление объекта
        function addObject() {
            const name = document.getElementById('objectName').value;
            const latitude = document.getElementById('objectLatitude').value;
            const longitude = document.getElementById('objectLongitude').value;

            if (name && latitude && longitude) {
                fetch('add_object.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: `name=${encodeURIComponent(name)}&latitude=${encodeURIComponent(latitude)}&longitude=${encodeURIComponent(longitude)}`
                })
                .then(response => response.json())
                .then(data => {
                    console.log('Ответ от add_object.php:', data);
                    if (data.success) {
                        closeModal('addObjectModal');
                        loadObjects();
                        document.getElementById('objectName').value = '';
                        document.getElementById('objectLatitude').value = '';
                        document.getElementById('objectLongitude').value = '';
                    } else {
                        alert(data.message);
                    }
                })
                .catch(error => console.error('Ошибка:', error));
            } else {
                alert('Заполните все поля');
            }
        }

        // Редактирование объекта
        function editObject(projectId) {
            const newName = prompt('Введите новое название объекта:');
            if (newName) {
                fetch('edit_object.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: `project_id=${projectId}&name=${encodeURIComponent(newName)}`
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        loadObjects();
                    } else {
                        alert(data.message);
                    }
                });
            }
        }

        // Удаление объекта
        function deleteObject(projectId) {
            console.log('Попытка удалить объект с ID:', projectId);
            if (confirm('Вы уверены, что хотите удалить этот объект?')) {
                fetch('delete_object.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: `project_id=${encodeURIComponent(projectId)}`
                })
                .then(response => {
                    console.log('Статус ответа:', response.status);
                    return response.text(); // Сначала получим текст для отладки
                })
                .then(text => {
                    console.log('Текст ответа:', text);
                    try {
                        const data = JSON.parse(text);
                        console.log('Парсированный ответ:', data);
                        if (data.success) {
                            console.log('Объект успешно удалён');
                            loadObjects();
                        } else {
                            alert('Ошибка: ' + data.message);
                        }
                    } catch (e) {
                        console.error('Ошибка парсинга JSON:', e);
                        alert('Ошибка на сервере: неверный формат ответа');
                    }
                })
                .catch(error => {
                    console.error('Ошибка при удалении:', error);
                    alert('Ошибка при удалении объекта');
                });
            }
        }

        // Скачивание всех отчётов в Excel
        function downloadReportsExcel() {
            console.log('Скачивание всех отчётов в Excel...');
            window.location.href = 'export_reports_excel.php';
        }

        // Скачивание одобренных отчётов в Excel
        function downloadApprovedReportsExcel() {
            console.log('Скачивание одобренных отчётов в Excel...');
            window.location.href = 'export_approved_reports_excel.php';
        }

        // Скачивание всех отчётов на рассмотрении в Excel
        function downloadPendingReportsExcel() {
            console.log('Скачивание всех отчётов на рассмотрении в Excel...');
            window.location.href = 'export_pending_reports_excel.php';
        }

        // Скачивание одного отчёта в Excel
        function downloadSingleReport(reportId) {
            console.log(`Скачивание отчёта с ID ${reportId}...`);
            window.location.href = `export_single_report_excel.php?report_id=${reportId}`;
        }

        // Одобрение отчёта
        function approveReport(reportId) {
            if (confirm('Одобрить отчёт?')) {
                fetch('approve_report.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: `report_id=${reportId}`
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        loadPendingReports();
                        loadReports();
                    } else {
                        alert(data.message);
                    }
                })
                .catch(error => console.error('Ошибка:', error));
            }
        }

        // Отклонение отчёта
        function rejectReport(reportId) {
            if (confirm('Отклонить отчёт?')) {
                fetch('reject_report.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: `report_id=${reportId}`
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        loadPendingReports();
                    } else {
                        alert(data.message);
                    }
                })
                .catch(error => console.error('Ошибка:', error));
            }
        }

        // Инициализация
        <?php if ($is_logged_in): ?>
            openTab('<?php echo $user_role === 'admin' ? 'adminControls' : 'objectControls'; ?>');
            loadEmployees();
            loadObjects();
            loadReports();
            loadPendingReports();
        <?php endif; ?>

        // Закрытие модального окна при клике вне его
        window.onclick = function(event) {
            const loginModal = document.getElementById('loginModal');
            const employeeModal = document.getElementById('addEmployeeModal');
            const objectModal = document.getElementById('addObjectModal');
            if (event.target == loginModal) closeLoginModal();
            if (event.target == employeeModal) closeModal('addEmployeeModal');
            if (event.target == objectModal) closeModal('addObjectModal');
        }
    </script>
</body>
</html>