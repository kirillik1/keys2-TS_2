<?php
// Параметры подключения к базе данных (те же, что в боте)
$db_config = [
    'host' => 'localhost',
    'user' => 'root',
    'password' => '888999000',
    'db' => 'report_db',
    'port' => 3306
];

// Функция для подключения к базе данных
function get_db_connection() {
    global $db_config;
    try {
        $conn = new PDO(
            "mysql:host={$db_config['host']};dbname={$db_config['db']};port={$db_config['port']}",
            $db_config['user'],
            $db_config['password']
        );
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $conn;
    } catch (PDOException $e) {
        die("Ошибка подключения: " . $e->getMessage());
    }
}

// Функция для вывода данных из таблицы
function display_table($conn, $table_name, $columns) {
    $sql = "SELECT * FROM $table_name";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (count($results) > 0) {
        echo "<h2>Таблица: $table_name</h2>";
        echo "<table border='1'>";
        // Заголовки
        echo "<tr>";
        foreach ($columns as $col) {
            echo "<th>$col</th>";
        }
        echo "</tr>";
        // Данные
        foreach ($results as $row) {
            echo "<tr>";
            foreach ($columns as $col) {
                echo "<td>" . htmlspecialchars($row[$col]) . "</td>";
            }
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<h2>Таблица: $table_name</h2>";
        echo "<p>Нет данных.</p>";
    }
}

$conn = get_db_connection();
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Данные из базы данных Telegram-бота</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            padding: 8px;
            text-align: left;
            border: 1px solid #ddd;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <h1>Данные из базы данных</h1>

    <?php
    // Вывод таблицы users
    display_table($conn, 'users', ['user_id', 'name', 'role', 'points']);

    // Вывод таблицы projects
    display_table($conn, 'projects', ['project_id', 'project_name', 'latitude', 'longitude', 'manager_id']);

    // Вывод таблицы shifts
    display_table($conn, 'shifts', ['shift_id', 'user_id', 'object_id', 'start_time', 'end_time', 'status', 'has_deviation']);

    // Вывод таблицы reports
    display_table($conn, 'reports', [
        'report_id', 'user_id', 'project_id', 'report_date', 'tasks_completed',
        'issues', 'approved', 'deviation', 'start_time', 'end_time'
    ]);

    // Вывод таблицы logs
    display_table($conn, 'logs', ['log_id', 'user_id', 'action', 'timestamp']);
    ?>

</body>
</html>

<?php
$conn = null; // Закрытие соединения
?>